package com.hsgd.public_mqtt_client_core;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PublicMqttClientCoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
