package com.hsgd.public_mqtt_client_core;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PublicMqttClientCoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(PublicMqttClientCoreApplication.class, args);
	}

}
